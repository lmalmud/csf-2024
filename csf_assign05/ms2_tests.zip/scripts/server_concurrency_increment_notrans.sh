#! /usr/bin/env bash

exec scripts/incr_value_concurrent.sh "$@"
